import React from "react";

export default function Modal({ modal, setModal, addUser, setAddUser, addPhone, setAddPhone }) {
   if (modal == null) {
      return null;
   }
   return (
      <div className="modal">
         <div className="modal__title">
            <h3>New visitor</h3>
            <p className="close" onClick={() => { setModal(null) }}>X</p>
         </div>

         <form>
            <label for='text'>Name</label>
            <input type='text' onChange={e => setAddUser(e.target.value)} />
            <label for='tel'>Phone</label>
            <input type='tel' onChange={e => setAddPhone(e.target.value)} />
         </form>
         <div className="save" onClick={() => {
            setAddPhone(addPhone);
            setAddUser(addUser);
         }}>
            <p>save</p>
         </div>
      </div>
   );
}