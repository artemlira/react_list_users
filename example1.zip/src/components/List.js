import React from "react";

export default function List({ addUser, addPhone }) {
   return (
      <>
         <ul>
            <li>{addUser}</li>
            <li>{addPhone}</li>
         </ul>
      </>
   );
}